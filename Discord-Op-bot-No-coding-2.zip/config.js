exports.PREFIX = ">";
exports.OWNER_ID = "832324578440380426";
exports.Owner_Name = "Wumpus#1071";